




                -------------------------------------------------------------------------------------------------------------------------------------------------
                -----------------------------------------------------PROJET DE CALCULATRICE----------------------------------------------------------------------
                -------------------------------------------------------------------------------------------------------------------------------------------------


                -------------------------------------------------------------------------------------------------------------------------------------------------

                -------------------------------------------------------------------------------------------------------------------------------------------------- 
 

               -----------------------------------------------------les fonctionnalités implémentées :-----------------------------------------------------------


             * projet concerne une calculatrice pour langage de script bash avec interface graphique en utilisant Zenity .Le Menu principal contient:membres de l’équipe: nom des membres de l’équipe 
              documentaions: la description du projet .
              le projet: ceci s’ouvrira sur un autre menu pour choisir le mode de la calculatrice nous avons 3 modes :arithmétique,scientifique,programmeur 

             * arithmétique pour addition,substraction,multiplication,division,power,absoulu,factorial,ln,log,exit
               en utilise pour ce mode (arithmétique ) les fonctions suivant :
               add(addition) ,sub(substraction),multi(multiplication),div(division),pow(la puissance d une nombre ),abs(la valeur absolu ),fact( factorail ),ln(logarithm),log(logarithm base 10) 
               et pour quitter en clique sur exit 
             * scientifique pour calculé sin,cos,arcos,tan,aton en utilise les fonctions suivant :
                   
                 sin, cos,acos(calculé arc cos d'un nombre),tan,asin,arsin(calculé arc sin d'un nombre ),atan(arc tangent d'un nombre )

             * programmer: pour convertir par exemple un nombre en décimal a binaire et octal et hexadéciaml  en utilise les fonctions suivant :

                 d2b( décimal vers binaire ),d2o(décimal vers octal),d2h(décimal vers héxadéciaml),h2d(hexadéciaml vers décimal ), h2b(héxadécimal to binaire ),h2o(héxadécimal vers octal),o2b(octal vers binaire)
                 o2d(octal vers décimal),b2d(binaire vers decimal),b2h(binaire vers octal),b2h(binaire vers héxadecimal)


               ----------------------------------------------------------------------------------------------------------------------------------------------                            

  


  